# Handoff: Local AI mobile redesign

## Overview
A redesign of the Local AI mobile app ("Recommendations near you") — the Flask/Jinja app at
`Dmans27/Ai-app-Repo` (branch `main`, UI under `templates/`). It covers first-run
onboarding, home, search, saved, account and settings for iOS-sized phones.

The committed direction is the **Near me** home: a map plate at the top with a
distance-ordered list of places below it, plus Open now / Top rated filters. Two rejected
home layouts (ask-first, and a curated "tonight's edition") are preserved in
`Local AI Redesign - options v1.dc.html` for reference only — do not build them.

Key structural changes from the current app:
- The hamburger drawer is removed. A four-item tab bar (Home, Search, Saved, Account)
  covers every route the drawer held. Settings is reached from Account, not the tab bar.
- Cards and panels are removed. Places sit directly on the page ground, separated by
  whitespace; hierarchy comes from the serif type scale.
- Emoji icons are replaced with Phosphor duotone icons.
- Onboarding is three short steps rather than one long form. The questions themselves are
  unchanged from `templates/onboarding.html`.
- Account gains a globe of the user's pinned (saved) places.
- Discover and Feed are folded into Home and Saved. Confirm with the product owner before
  deleting those routes.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing the
intended look and behavior. They are not production code to copy directly. They use a
custom in-house component runtime (`support.js`, `.dc.html` templates) that should not be
introduced into the app.

The task is to **recreate these designs in the target codebase's existing environment**.
For this repo that means server-rendered Jinja templates under `templates/` plus the
existing stylesheet — matching the app's current routing, template inheritance and static
asset conventions. If the team is moving to a client framework instead, implement the same
screens there using that framework's established patterns.

## Fidelity
**High fidelity.** Colors, typography, spacing, icon set, copy and interaction states are
final and should be matched closely. Two explicit exceptions, both placeholders:
- **Photographs** — every image is a grey halftone placeholder. Real photography is needed.
- **The map** — a static grey plate with dots. Needs a real map SDK (see Open Questions).

## Design Tokens
From the Broadsheet design system (bundled under `_ds/`). Ramps are OKLCH-generated on a
shared perceptual lightness scale; use ramp steps rather than ad-hoc `color-mix()`.

### Color
| Token | Hex | Use |
| --- | --- | --- |
| `--color-bg` | #f3f2f2 | Page ground, tab bar, bottom sheet |
| `--color-text` | #201e1d | All body and heading text; masthead rules |
| `--color-accent` | #0088b0 | Every interactive element: primary buttons, active tab, selected chips, map pins, focus ring |
| `--color-accent-2` | #d6006c | Second spot color. Used twice only: the star rating in the place sheet, and "Delete account" |
| `--color-neutral-200` | — | Empty photo-upload circle fill |
| `--color-neutral-300` | — | Photo and map placeholder fill |
| `--color-neutral-400` | — | Unselected chip borders, input underlines, toggle off-track, sheet grab handle |
| `--color-neutral-500` | — | Outer edge of the account globe gradient |
| `--color-neutral-600` | — | Inactive tab icons and labels, unsaved bookmark icon, end-of-list notes |
| `--color-neutral-700` | — | Metadata lines, section eyebrows, placeholder captions |
| `--color-neutral-800` | — | Secondary body copy |
| `--color-accent-100` | — | Row hover tint, selected intent row background |
| `--color-accent-300` | — | Large empty-state bookmark glyph |
| `--color-accent-700` | — | Accent-colored text at paragraph size (eyebrows, links, distances, active tab). **Never use `--color-accent` itself for small text — it is only 3:1 on this ground.** |
| `--color-accent-800` | — | Text on accent-100 fills |
| `--color-accent-2-700` | — | Star rating, "Delete account" eyebrow |
| `--color-divider` | — | The single 1px rule above the tab bar |

Two literal rgba values are used for effects and have no token: `rgba(0,136,176,0.24)` for
the halo around map and globe pins, and `rgba(32,30,29,0.34)` for the bottom-sheet scrim.

### Typography
Source Serif 4 throughout — headings and body both. The italic is a real loaded italic;
never synthesize an oblique. **Do not introduce a sans-serif for UI chrome; the serif is
the chrome**, including tab bar labels.

| Role | Size / line-height | Treatment |
| --- | --- | --- |
| Masthead wordmark | 15px | uppercase, letter-spacing 0.3em |
| Masthead subtitle | 11.5px | letter-spacing 0.06em, neutral-700 |
| Dateline rail (city, time) | 10px | uppercase, letter-spacing 0.14em, neutral-700 |
| Screen title (h1) | 28–30px / 1.08 | heading font |
| Onboarding h1 | 34px / 1.06 | `text-wrap: pretty` |
| Section question (onboarding h2) | 23px | heading font |
| Place name in list | 20px / 1.16 | heading font |
| Place name in sheet | 29px / 1.08 | heading font |
| Section eyebrow | 10.5px | uppercase, letter-spacing 0.16em |
| Category eyebrow on a row | 10px | uppercase, letter-spacing 0.16em, accent-700 |
| Body copy | 15–17px / 1.5–1.55 | `text-wrap: pretty` on long paragraphs |
| Metadata line | 12.5px | neutral-700 |
| Tab bar label | 9.5px | uppercase, letter-spacing 0.12em |
| Distance marker (Near me list) | 13px | heading font, accent-700, min-width 34px |

Minimum interactive size is 44x44px; every button in the design meets it.

### Spacing, radius, elevation
Screen gutter is 20px on every screen. Radius: `--radius-sm` on image plates,
`--radius-md` on chips and buttons, `--radius-lg` on the top corners of the bottom sheet,
999px on pills, toggles and circles. Elevation: `--shadow-lg` on the bottom sheet only —
nothing else in the app is elevated. Do not tighten the spacing scale.

### Icons
Phosphor duotone (`@phosphor-icons/web`, `ph-duotone` class). Icons used:
`ph-house`, `ph-magnifying-glass`, `ph-bookmark-simple`, `ph-bookmark-simple-fill`,
`ph-user`, `ph-user-circle`, `ph-paper-plane-right`, `ph-arrow-left`, `ph-camera`,
`ph-check`. Tab icons are 23px, header and sheet icons 21–26px.

## Persistent Chrome

### Masthead (all screens except onboarding)
Top padding 56px (below the status bar), 20px gutters. Left: the wordmark "Local AI"
(15px, uppercase, 0.3em tracking) with "Recommendations near you" beneath it (11.5px,
neutral-700). Right: a `ph-user-circle` button, 26px, navigating to Account.

Below that a **3px solid `--color-text` rule**, then a 5px-padded row of 10px uppercase
neutral-700 text — the user's city on the left, day and time on the right — then a
**1px solid `--color-text` rule**. This thick-thin pair is the only place rules are drawn
in the app; it is front-page furniture, not a divider. Do not add rules elsewhere.

### Tab bar (all screens except onboarding)
Fixed to the bottom. Padding 6px 4px 34px (the bottom value clears the home indicator),
a 1px `--color-divider` top border, page-ground background. Four equal flex items, each a
44px-minimum column of a 23px duotone icon over a 9.5px uppercase label: Home, Search,
Saved, Account. Active is `--color-accent-700`; inactive `--color-neutral-600`. Settings
counts as Account for the active state.

## Screens

### 1. Onboarding (3 steps)
**Purpose:** collect tastes so recommendations can be personalized. Questions are verbatim
from `templates/onboarding.html`. No masthead, no tab bar.

Header: 64px top padding, eyebrow "Welcome to Local AI" (11px, uppercase, 0.18em,
accent-700), h1 "Personalize your recommendations" (34px/1.06), then "Pick what you love so
Local AI can suggest better places for you." (16.5px). Then the same thick-thin rule pair
as the masthead, with the step name on the left ("Your tastes", "Where and why", "Budget
and photo") and "Step N of 3" on the right.

**Step 1 — "What kinds of places do you like?"** A wrapping row of 8px-gapped multi-select
chips: Coffee, Restaurants, Bars, Rooftops, Brunch, Wine, Date Spots, Hidden Gems,
Shopping, Work Cafes. Unselected: transparent fill, 1px neutral-400 border, text color.
Selected: accent fill, white text, accent border. Chips are 10px 14px, radius-md, 44px min
height. Below: "N picked", or "Pick as many as you like" when none. Defaults: Coffee, Wine.

**Step 2 — city and intent.** "What city do you explore most?" over a text input styled as
a 2px `--color-text` bottom rule only (19px text, no box, no fill; the rule turns accent
on focus), placeholder "Chicago, Naperville, Miami...". Then "What brings you here most?"
with five single-select rows, 18px heading font, left-aligned, 44px min height: Find
tonight's plans, Save favorite places, Plan dates, Discover food, Travel planning. The
selected row takes an accent-100 fill, accent-800 text and a trailing checkmark. Hover is
accent-100.

**Step 3 — budget and photo.** "What's your usual budget?" with four single-select chips
(Budget, Moderate, Premium, Mix of everything; default Moderate) styled like step 1. Then
"Add a profile photo": a 72px circle (halftone, neutral-200 empty / neutral-400 filled)
with a `ph-camera` glyph, beside "Upload photo" in accent-700. Once a photo exists the
glyph becomes `ph-check` and the label "Photo added". In the prototype this is a toggle
stub; wire it to a real file picker and upload.

**Footer, all steps:** a primary button reading "Continue" (steps 1–2) or "Finish setup"
(step 3), beside a ghost "Skip for now". Both routes land on Home.

### 2. Home — Near me (committed layout)
**Purpose:** decide where to go, usually while already out.

Order down the screen:
1. Eyebrow: time-aware greeting (Good morning / afternoon / evening), 12px uppercase 0.14em
   accent-700.
2. h1 "Near you right now", 30px/1.08.
3. **Map plate.** 20px side margins, 230px tall, neutral-300 fill, halftone screen,
   radius-sm. A 10px uppercase neutral-700 caption "Map placeholder" top-left. Pins are
   12–14px accent circles; the user's own position takes the accent halo. One pin uses
   `--color-accent-2` — decorative in the prototype; in production reserve it for a single
   meaningful state (e.g. the selected pin) or drop it, since the two accents should not
   both appear in one small component.
4. **Filter row.** Three single-select pills — All, Open now, Top rated — 13px uppercase
   0.08em, 8px 12px, radius-md. Selected: accent fill, white text. Unselected: transparent,
   neutral-400 border. "Open now" filters to open places; "Top rated" to rating >= 4.5.
5. **Place list**, ordered by distance ascending. Each row: the distance in accent-700
   heading font at 13px in a 34px-min-width left column, then the place name (20px/1.16
   heading) with a metadata line beneath (12.5px neutral-700, format
   `★ 4.8 (541) · 0.2 mi · Open now`). At the right edge, a 21px bookmark toggle —
   `ph-bookmark-simple` in neutral-600 when unsaved, `ph-bookmark-simple-fill` in
   accent-700 when saved. Tapping the row body opens the place sheet; tapping the bookmark
   toggles saved without opening.

### 3. Search
Title "Search" (28px). A search field styled as a 2px `--color-text` bottom rule with a
20px `ph-magnifying-glass` at the left, 18px input text, placeholder "Where should I go?"
(the current app's phrasing). Beneath it a 10.5px uppercase neutral-700 count line:
`N places for "query"`, or "Everything near you" when empty.

Result rows carry a `Category · Open now` eyebrow, the place name at 20px, the metadata
line, and the same bookmark toggle. Empty result state: "Nothing matched that" (21px
heading) over "Try a plainer phrase — "coffee", "rooftop", "brunch" — or ask on the home
screen."

**Matching in the prototype** is client-side over name, category, tag list and address: the
query is lowercased, split on whitespace, words of 3+ characters kept, a trailing "s"
stripped, and a place matches if **any** word is a substring of its haystack. This is a
stand-in — replace it with the app's existing AI recommendation endpoint rather than
porting this logic.

### 4. Saved
Title "Saved" over an 11px uppercase count ("N places saved"). Rows show the category
eyebrow, name, metadata line, and a filled bookmark that removes the place; the remove icon
hovers to `--color-accent-2-600`. Below the list, a secondary "Share this list" beside a
ghost "New list" — both unwired stubs.

**Empty state:** a 40px `ph-bookmark-simple` glyph in accent-300, "Nothing saved yet"
(22px heading), "Tap the mark next to a place and it waits here, ready to share as a list.",
and a primary "Find somewhere" button routing to Home.

### 5. Account
Header row: a 64px halftone circle avatar beside the user's name (24px heading) and a
secondary line of city plus saved count.

**Globe of pinned places** (added at the user's request). Eyebrow "Your pinned places" left,
"N pinned" in accent-700 right. Below, a centered 290x290px circle filled with a radial
gradient from `--color-neutral-200` at 36% 30% through `--color-neutral-400` at 78% to
`--color-neutral-500`, with the halftone screen over it. Three 9px uppercase neutral-700
continent labels sit as placeholder geography (North America 18%/44%, Europe 72%/24%, South
America 52%/78%). Each saved place renders as a 44x44px tap target centered on its
coordinate containing a 13px accent dot with the `rgba(0,136,176,0.24)` halo; tapping opens
that place's sheet.

**In the prototype the pin coordinates are fake** — they cycle through a fixed list of six
percentage positions. In production, project each saved place's real latitude/longitude onto
the globe. If a true 3D globe is wanted, this is where a map SDK's globe projection goes;
otherwise an orthographic projection over a static sphere is sufficient. When nothing is
saved, show "Nothing pinned yet. Save a place and it lands here." beneath the empty globe.

**Rows** below the globe, each 15px vertical padding with an accent-100 hover, a 19px
heading label left and 12.5px neutral-700 detail right: Settings ("Profile, lists,
account"), Saved places (count), Redo setup ("Tastes and budget", restarts onboarding),
Privacy policy, Contact support.

Footer: eyebrow "Your lists" over "Places I saved from Local AI" (19px heading) and the
saved count — matching the list name the current backend creates.

### 6. Settings
Reached from Account; has a `ph-arrow-left` back button (44px min height) returning there.
Title "Settings" over "Manage your profile, lists, and account." Fields are from
`templates/settings.html`.

**Profile details:** eyebrow, then labelled inputs for Name and Home city — 12.5px
neutral-700 labels over 18px inputs with a 1px neutral-400 bottom rule that turns accent on
focus. A primary "Save changes" button that reads "Saved" after submitting.

**Notifications** (new): two rows, each a label beside a 46x27px pill toggle. Track is
`--color-accent` when on, `--color-neutral-400` when off; the 21px white knob moves
between left 3px and left 22px with a 0.18s transition on both properties. Rows: "Today's
picks at 5pm" (default on) and "When I am near a saved place" (default off). These need
backend support and push permission — they do not exist in the current app.

**Delete account:** a `--color-accent-2-700` eyebrow, the warning "This will permanently
delete your account. This action cannot be undone." and an outlined destructive button in
`--color-accent-2` that fills accent-2-100 on hover. This is the existing app's copy; keep
the confirmation step the current implementation uses.

### 7. Place detail (bottom sheet)
Opens over any screen when a place is tapped. A `rgba(32,30,29,0.34)` scrim closes it on
tap. The sheet is bottom-anchored, max-height 82%, scrollable, page-ground fill,
`--shadow-lg`, radius-lg on the top two corners only, with a 44x4px neutral-400 grab
handle centered at the top.

Content: a 170px halftone photo placeholder, then a `Category · Open now` eyebrow, the
place name at 29px/1.08, and a metadata row of `★ 4.8` in accent-2-700, "(541 reviews)",
distance and price level. Then the recommendation reason at 16px/1.55 and the street address
at 13.5px neutral-700. Footer: a primary button reading "Save this place" (or "Saved" once
saved) beside a secondary "Directions" — Directions is an unwired stub.

## Interactions & Behavior
- **Tab navigation** switches screens and closes any open place sheet.
- **Bookmark toggles** add or remove the place id from the saved list and update every
  screen at once: the Saved list, the Account globe pins, the saved counts, and the sheet's
  button label. Newly saved places are prepended.
- **Onboarding** advances one step per Continue; "Finish setup" and "Skip for now" both go
  to Home. Redo setup from Account re-enters at step 1.
- **Search** re-filters on every keystroke.
- **Row hover** is an accent-100 tint on Account rows; icon buttons shift to
  `--color-accent-600`.
- **Focus:** `:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 2px; }`
  on everything interactive. Never leave the browser default.
- The only animated properties in the design are the toggle's background and knob offset,
  both 0.18s. There are no other transitions and no page transitions.
- **Not designed yet:** loading states, error states, offline behavior, permission prompts
  for location and push, and form validation. These need design before implementation.

## State Management
Prototype state, as a guide to what each screen needs:

| State | Type | Notes |
| --- | --- | --- |
| `screen` | enum | home, search, saved, account, settings, onboarding — replace with real routing |
| `step` | 0–2 | onboarding position |
| `query` | string | search text |
| `saved` | string[] | saved place ids; must persist server-side per user |
| `detail` | place id or null | which place sheet is open |
| `filter` | all / open / top | Near me list filter |
| `cats` | string[] | selected taste categories |
| `intent` | string or null | onboarding intent answer |
| `budget` | string | onboarding budget answer |
| `photo` | boolean | stub; becomes an uploaded avatar URL |
| `name`, `city` | string | settings fields |
| `notif` | { picks, nearby } | notification toggles |

Data fetching the real app needs, none of which the prototype does: the recommendation query
(Search and Home lists), nearby places by coordinate (the map), the user's saved places and
lists, profile read/write, and geocoding for the city field.

## Assets
- **Phosphor Icons** duotone weight, from `@phosphor-icons/web`. Self-host or bundle rather
  than relying on the CDN in production.
- **Source Serif 4** — the design system's only typeface, headings and body.
- **No photography exists.** Every photo, the map plate and the globe are grey halftone
  placeholders. Real place photography, map tiles and avatar images are all needed. The
  design system prints photographs through a `.cmyk` process-plate treatment for showcase
  imagery and a `.halftone` dot screen for interface imagery — this app uses `.halftone`
  throughout.
- **Place content is invented.** The six Naperville places (Wildseed Coffee, Ember & Rye,
  Quarry Books & Cafe, Saoirse Kitchen, Rooftop at the Marquette, Paper Crane Brunch) are
  fixtures written to match the real data shape: id, name, category, rating, review count,
  distance, price level, open flag, address, reason text, tag list. Nothing here is real.

## Files
In this bundle:
- `LocalAIPhone.dc.html` — every screen. The template holds the markup for all screens and
  the place sheet; the logic class at the bottom holds state, the place fixtures, the
  category/intent/budget option lists and the search matcher.
- `Local AI Redesign.dc.html` — the review board: the committed screens side by side with
  design notes.
- `Local AI Redesign - options v1.dc.html` — the two rejected home layouts, for reference.
- `ios-frame.jsx` — the iPhone bezel, presentation only. Not part of the app.
- `support.js` — the prototype runtime. Do not port.
- `_ds/` — the Broadsheet design system: `styles.css` carries every token, `readme.md` the
  full usage guidance. Worth reading before implementing.

Source templates these screens were built from, in `Dmans27/Ai-app-Repo@main`:
`templates/directory_home.html` (greeting, ask input, quick chips, recommendation rows and
filters), `templates/onboarding.html`, `templates/settings.html`, `templates/account.html`,
`templates/profile.html`, `templates/search_results.html`.

## Open Questions
1. **Map SDK** — Google Maps or Mapbox? This decides the map plate, the pin styling and the
   Account globe projection. Both need styling down to a greyscale ground so the map reads
   as a printed plate rather than a stock map.
2. **Photography** — who supplies place photos, and what is the fallback when a place has none?
3. **Discover and Feed** — retired, or do they return as a fifth tab?
4. **Notifications** — is there backend support for the two toggles, or should they be cut
   from the first release?
5. **Share this list / New list / Directions** — designed as buttons but unspecified.
